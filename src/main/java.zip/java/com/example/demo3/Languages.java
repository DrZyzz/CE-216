package com.example.demo3;

public enum Languages {
    ENG,
    TUR,
    DEU,
   FRA,
   ELL,
   SWE,
   ITA,
}
